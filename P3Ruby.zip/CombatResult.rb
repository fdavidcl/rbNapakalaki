#!/usr/bin/env ruby
#encoding: utf-8

module Game
    # CombatResult
    WINANDWINGAME = :wingame
    WIN = :win
    LOSE = :lose
    LOSEANDESCAPE = :escape
    LOSEANDDIE = :die
end