#!/usr/bin/env ruby
#encoding: utf-8

module Game
    # TreasureKind (tipos de tesoros)
    ARMOR = :armor
    ONEHAND = :onehand
    BOTHHANDS = :bothhands
    HELMET = :helmet
    SHOE = :shoe
    NECKLACE = :necklace
end